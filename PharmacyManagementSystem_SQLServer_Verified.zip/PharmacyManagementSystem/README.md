# Pharmacy Management System (.NET 10 + SQL Server)

This is the SQL Server version of the project. It contains three ASP.NET Core services, a YARP API Gateway, an Angular frontend, and SQL Server database scripts.

## Prerequisites
- .NET 10 SDK
- Node.js LTS and npm
- SQL Server Database Engine (SSMS alone is not a database engine)
- RabbitMQ is planned; it is not yet wired end-to-end.

## 1. Configure SQL Server
The three services currently use Windows Authentication with `localhost` as the server. If your SQL Server is a named instance, change `Server=localhost` in each service `appsettings.json` to e.g. `Server=localhost\SQLEXPRESS`. For SQL authentication, replace `Trusted_Connection=True` with `User Id=...;Password=...;` and keep credentials out of source control.

Open each script in SSMS and execute it separately, in this order:
1. `database/01_users.sql`
2. `database/02_inventory.sql`
3. `database/03_orders.sql`

These scripts create `pharmacy_users`, `pharmacy_inventory`, and `pharmacy_orders`.

## 2. Restore and build backend
From the repository root:
```powershell
dotnet restore .\backend\PharmacyManagement.sln
dotnet build .\backend\PharmacyManagement.sln
```

## 3. Install and build Angular
```powershell
cd .\frontend\pharmacy-ui
npm install
npm run build
```

## Important status
This is a development foundation, not yet a fully verified end-to-end application. The SQL Server provider and connection templates have been switched from MySQL. Complete business workflows, RabbitMQ publishing/consuming, integration tests, and full frontend flows still need implementation and verification. Do not use production data or deploy publicly yet.


## Local development ports
- Angular: `http://localhost:4200`
- API Gateway: `http://localhost:5100` (HTTPS `https://localhost:7100`)
- Users API: HTTP `5101` / HTTPS `7101`
- Inventory API: HTTP `5102` / HTTPS `7103`
- Orders API: HTTP `5103` / HTTPS `7102`

The Angular API service targets the Gateway HTTP port `5100`. The Gateway forwards to the three HTTP service ports.

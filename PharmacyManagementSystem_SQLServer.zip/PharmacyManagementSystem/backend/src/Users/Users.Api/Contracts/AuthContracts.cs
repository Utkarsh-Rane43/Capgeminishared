namespace Users.Api.Contracts;
public record RegisterRequest(string Name,string Contact,string Email,string Password);
public record LoginRequest(string Email,string Password);
public record AuthResponse(string Token,string Name,string Email,string Role);
public record UserDto(int Id,string Name,string Contact,string Email,string Role,bool IsActive);

using Microsoft.AspNetCore.Authorization; using Microsoft.AspNetCore.Mvc; using Microsoft.EntityFrameworkCore; using Users.Api.Contracts; using Users.Api.Data;
namespace Users.Api.Controllers;
[ApiController][Route("api/users")][Authorize(Roles="ADMIN")]
public sealed class UsersController(UsersDbContext db):ControllerBase{[HttpGet] public async Task<ActionResult<IEnumerable<UserDto>>> Get()=>Ok(await db.Users.AsNoTracking().Select(x=>new UserDto(x.Id,x.Name,x.Contact,x.Email,x.Role,x.IsActive)).ToListAsync()); [HttpPatch("{id:int}/status")] public async Task<IActionResult> SetStatus(int id,[FromQuery]bool active){var u=await db.Users.FindAsync(id);if(u is null)return NotFound();u.IsActive=active;await db.SaveChangesAsync();return NoContent();}}

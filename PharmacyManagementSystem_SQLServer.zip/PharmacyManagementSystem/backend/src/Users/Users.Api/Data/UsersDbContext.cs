using Microsoft.EntityFrameworkCore; using Users.Api.Models;
namespace Users.Api.Data;
public sealed class UsersDbContext(DbContextOptions<UsersDbContext> options):DbContext(options){ public DbSet<User> Users=>Set<User>(); protected override void OnModelCreating(ModelBuilder b){b.Entity<User>().HasIndex(x=>x.Email).IsUnique(); b.Entity<User>().Property(x=>x.Email).HasMaxLength(254); b.Entity<User>().Property(x=>x.Role).HasMaxLength(20);}}

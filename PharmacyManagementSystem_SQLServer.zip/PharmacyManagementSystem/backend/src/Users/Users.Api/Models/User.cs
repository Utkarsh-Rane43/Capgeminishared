namespace Users.Api.Models;
public sealed class User { public int Id {get;set;} public string Name {get;set;}=""; public string Contact {get;set;}=""; public string Email {get;set;}=""; public string PasswordHash {get;set;}=""; public string Role {get;set;}="DOCTOR"; public bool IsActive {get;set;}=true; public DateTime CreatedAtUtc {get;set;}=DateTime.UtcNow; }

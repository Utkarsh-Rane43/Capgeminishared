namespace Orders.Api.Contracts;public record CreateOrderRequest(List<CreateOrderItem>Items);public record CreateOrderItem(int DrugId,int Quantity);public record RejectOrderRequest(string Reason);

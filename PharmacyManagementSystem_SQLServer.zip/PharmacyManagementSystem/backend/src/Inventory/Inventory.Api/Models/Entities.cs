namespace Inventory.Api.Models;
public sealed class Drug{public int Id{get;set;} public string Name{get;set;}=""; public string Sku{get;set;}=""; public string Description{get;set;}=""; public string Category{get;set;}=""; public decimal UnitPrice{get;set;} public bool IsActive{get;set;}=true;}
public sealed class Supplier{public int Id{get;set;} public string Name{get;set;}=""; public string Contact{get;set;}=""; public string Email{get;set;}=""; public string Address{get;set;}=""; public bool IsActive{get;set;}=true;}
public sealed class InventoryBalance{public int Id{get;set;} public int DrugId{get;set;} public int OnHand{get;set;} public int Reserved{get;set;} public byte[] RowVersion{get;set;}=[];}
public sealed class Sale{public int Id{get;set;} public int OrderId{get;set;} public decimal Total{get;set;} public DateTime SoldAtUtc{get;set;}=DateTime.UtcNow;}
public sealed class StockMovement{public long Id{get;set;} public int DrugId{get;set;} public int QuantityChange{get;set;} public string Type{get;set;}="ADJUSTMENT"; public string? Reference{get;set;} public DateTime CreatedAtUtc{get;set;}=DateTime.UtcNow;}

# Implementation plan

1. Build baseline and fix compile/runtime issues on .NET 10.
2. Add inventory reservation aggregate and concurrency-safe/idempotent endpoints.
3. Implement typed service-to-service clients and authoritative order price snapshots.
4. Implement outbox dispatcher, RabbitMQ exchanges/queues, inbox deduplication, retries and DLQ.
5. Complete Angular login/signup, role guards, admin CRUD, doctor order basket, order actions, reports, CSV/PDF export.
6. Add xUnit unit/integration tests, migrations, exception middleware, validation and structured logging.
7. Run full end-to-end tests against MySQL and RabbitMQ.

# Requirements mapped from supplied HLD

## Roles
**Admin:** login; view/add/edit/deactivate drugs; view/add/edit/deactivate suppliers; review all doctor orders; verify/reject orders; confirm pickup; view, print and download sales reports.

**Doctor:** signup/login; browse medicines; place orders; view own order history and statuses.

## Architecture
Four deployable ASP.NET Core applications: API Gateway, Users API, Orders API and Supplier-Inventory API. Each business service owns a MySQL database. Angular is the website. RabbitMQ is the asynchronous messaging broker.

## Order lifecycle
Pending -> Verified -> Picked Up, or Pending -> Rejected. Cancellation and reservation failure are planned extensions. Verification must reserve stock. Pickup must consume the reservation and create a single sale. These transitions require transactional/idempotent implementation before production.

## Quality requirements
Exception handling, automated test cases, static analysis, build tooling, API documentation, health endpoints and independent service data ownership.

# Database setup
Run the three `.sql` scripts in SSMS, one at a time. They create separate databases for Users, Inventory, and Orders. Scripts are SQL Server T-SQL, not MySQL.

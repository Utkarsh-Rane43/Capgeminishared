$ErrorActionPreference = "Stop"
dotnet restore ./backend/PharmacyManagement.sln
dotnet build ./backend/PharmacyManagement.sln
Write-Host "Build completed. Start each service using the commands in README.md."

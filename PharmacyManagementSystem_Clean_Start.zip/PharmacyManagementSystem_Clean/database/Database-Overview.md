# Pharmacy Management System - Database Overview

See the separate `Pharmacy_Database_Design.docx` document for the full table descriptions and schema diagrams.

Database names:
- pharmacy_users
- pharmacy_inventory
- pharmacy_orders

The databases are owned by separate APIs. There are no cross-database foreign keys.

## Tables
Users database:
- Users

Inventory database:
- Drugs
- Suppliers

Orders database:
- Orders
- OrderItems

Application data is accessed using Entity Framework Core and LINQ. EF Core migrations create and update the schema.

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  standalone: true,
  template: `
    <header class="topbar">
      <h1>Pharmacy Management System</h1>
      <div class="header-buttons">
        <button (click)="selectRole('Doctor')">Doctor Login</button>
        <button (click)="selectRole('Admin')">Admin Login</button>
      </div>
    </header>

    <main>
      <aside class="sidebar">
        <h3>Menu</h3>
        <button (click)="page = 'Dashboard'">Dashboard</button>
        <button (click)="page = 'Drugs'">View Drugs</button>
        <button (click)="page = 'Orders'">Orders</button>
        <button (click)="page = 'Suppliers'">Suppliers</button>
        <button (click)="page = 'Sales'">Sales Report</button>
      </aside>

      <section class="content">
        <h2>{{ page }}</h2>
        <p>Welcome to the Pharmacy Management System.</p>
        <p class="note">Selected role: {{ selectedRole }}</p>
        <p>This is the frontend starting point. API integration will be added after the database is configured.</p>
      </section>
    </main>
  `
})
export class AppComponent {
  page = 'Dashboard';
  selectedRole = 'Not selected';

  selectRole(role: string) {
    this.selectedRole = role;
  }
}

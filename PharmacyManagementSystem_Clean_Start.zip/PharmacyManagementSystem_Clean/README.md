# Pharmacy Management System

A simple Pharmacy Management System built for a college case study.

## Technologies
- ASP.NET Core Web API on .NET 10
- Entity Framework Core 10
- LINQ for querying data through Entity Framework
- SQL Server / LocalDB
- Angular frontend (starter UI)

## Three APIs
1. Users.Api - doctor registration, login and user details.
2. Inventory.Api - drugs and suppliers.
3. Orders.Api - order placement, order listing and status updates.

Each API has its own database. The APIs do not share DbContexts or directly access another service's database.

## Important: database setup
The application uses Entity Framework Core. Do not write SQL INSERT/UPDATE/DELETE statements for application data.
Create the databases and tables using EF Core migrations. LINQ is used for filtering, sorting and selecting records. Add/Update/Remove and SaveChangesAsync are used for data changes.

The SQL Server LocalDB connection strings are in each API's appsettings.json:
- Users: pharmacy_users
- Inventory: pharmacy_inventory
- Orders: pharmacy_orders

If your LocalDB instance is different, change the Server part of the connection string.

## Build
Install the .NET 10 SDK, then run from this folder:

```powershell
dotnet restore .\backend\PharmacyManagement.sln
dotnet build .\backend\PharmacyManagement.sln
```

## Create database tables
Install EF tools once:

```powershell
dotnet tool install --global dotnet-ef --version 10.0.0
```

Run migrations for each API:

```powershell
dotnet ef migrations add InitialCreate --project .\backend\src\Users.Api
dotnet ef database update --project .\backend\src\Users.Api

dotnet ef migrations add InitialCreate --project .\backend\src\Inventory.Api
dotnet ef database update --project .\backend\src\Inventory.Api

dotnet ef migrations add InitialCreate --project .\backend\src\Orders.Api
dotnet ef database update --project .\backend\src\Orders.Api
```

## Run the APIs
Open separate terminals from the project root:

```powershell
dotnet run --project .\backend\src\Users.Api
dotnet run --project .\backend\src\Inventory.Api
dotnet run --project .\backend\src\Orders.Api
```

Ports:
- Users API: http://localhost:5101
- Inventory API: http://localhost:5102
- Orders API: http://localhost:5103

Health endpoints:
- /health
- /health/database

## Angular
The frontend folder contains a simple starter UI. Run `npm install` inside `frontend/pharmacy-ui` after Node.js is installed.

namespace Orders.Api.Models;

public class CreateOrderRequest
{
    public int DoctorId { get; set; }
    public string DoctorName { get; set; } = "";
    public List<CreateOrderItemRequest> Items { get; set; } = new();
}

public class CreateOrderItemRequest
{
    public int DrugId { get; set; }
    public string DrugName { get; set; } = "";
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Orders.Api.Data;
using Orders.Api.Models;

namespace Orders.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrdersController : ControllerBase
{
    private readonly OrdersDbContext _context;

    public OrdersController(OrdersDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var orders = await _context.Orders
            .Include(order => order.Items)
            .OrderByDescending(order => order.OrderDate)
            .ToListAsync();

        return Ok(orders);
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        var order = await _context.Orders
            .Include(order => order.Items)
            .FirstOrDefaultAsync(order => order.Id == id);

        if (order == null)
        {
            return NotFound();
        }

        return Ok(order);
    }

    [HttpPost]
    public async Task<IActionResult> PlaceOrder(CreateOrderRequest request)
    {
        if (request.Items.Count == 0)
        {
            return BadRequest("An order must contain at least one drug.");
        }

        if (request.Items.Any(item => item.Quantity <= 0 || item.UnitPrice < 0))
        {
            return BadRequest("Enter a valid quantity and price.");
        }

        var order = new Order
        {
            DoctorId = request.DoctorId,
            DoctorName = request.DoctorName,
            Status = "Pending",
            Items = request.Items.Select(item => new OrderItem
            {
                DrugId = item.DrugId,
                DrugName = item.DrugName,
                Quantity = item.Quantity,
                UnitPrice = item.UnitPrice
            }).ToList()
        };

        order.TotalAmount = order.Items.Sum(item => item.Quantity * item.UnitPrice);

        _context.Orders.Add(order);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetById), new { id = order.Id }, order);
    }

    [HttpPut("{id:int}/status")]
    public async Task<IActionResult> UpdateStatus(int id, [FromQuery] string status)
    {
        string[] allowedStatuses = { "Pending", "Verified", "Rejected", "PickedUp" };

        if (!allowedStatuses.Contains(status))
        {
            return BadRequest("Invalid order status.");
        }

        var order = await _context.Orders.FindAsync(id);

        if (order == null)
        {
            return NotFound();
        }

        order.Status = status;
        await _context.SaveChangesAsync();

        return Ok(order);
    }
}

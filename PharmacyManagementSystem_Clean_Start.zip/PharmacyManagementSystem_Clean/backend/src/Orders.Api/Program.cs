using Microsoft.EntityFrameworkCore;
using Orders.Api.Data;

var builder = WebApplication.CreateBuilder(args);

// Add Web API controllers and connect to the Orders database.
builder.Services.AddControllers();

builder.Services.AddDbContext<OrdersDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("Orders")));

builder.Services.AddEndpointsApiExplorer();

var app = builder.Build();

app.MapControllers();

app.MapGet("/health", () => "Orders API is running");

app.MapGet("/health/database", async (OrdersDbContext db) =>
{
    bool connected = await db.Database.CanConnectAsync();

    return connected
        ? Results.Ok("Orders database connection successful.")
        : Results.Problem("Could not connect to the Orders database.");
});

app.Run();

using Microsoft.EntityFrameworkCore;
using Users.Api.Data;

var builder = WebApplication.CreateBuilder(args);

// Add the controller support used by this Web API.
builder.Services.AddControllers();

// Register the Users database.
builder.Services.AddDbContext<UsersDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("Users")));

builder.Services.AddEndpointsApiExplorer();

var app = builder.Build();

// Map controller routes.
app.MapControllers();

// Simple endpoint to check whether the API is running.
app.MapGet("/health", () => "Users API is running");

// Check whether this API can reach SQL Server.
app.MapGet("/health/database", async (UsersDbContext db) =>
{
    bool connected = await db.Database.CanConnectAsync();

    if (connected)
    {
        return Results.Ok("Users database connection successful.");
    }

    return Results.Problem("Could not connect to the Users database.");
});

app.Run();

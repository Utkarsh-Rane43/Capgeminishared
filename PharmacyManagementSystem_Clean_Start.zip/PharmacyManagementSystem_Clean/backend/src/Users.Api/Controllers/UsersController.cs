using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Users.Api.Data;
using Users.Api.Models;

namespace Users.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UsersController : ControllerBase
{
    private readonly UsersDbContext _context;
    private readonly PasswordHasher<User> _passwordHasher;

    public UsersController(UsersDbContext context)
    {
        _context = context;
        _passwordHasher = new PasswordHasher<User>();
    }

    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Name) ||
            string.IsNullOrWhiteSpace(request.Email) ||
            string.IsNullOrWhiteSpace(request.Password))
        {
            return BadRequest("Name, email and password are required.");
        }

        string email = request.Email.Trim().ToLower();

        bool emailExists = await _context.Users.AnyAsync(user => user.Email == email);
        if (emailExists)
        {
            return Conflict("An account with this email already exists.");
        }

        var user = new User
        {
            Name = request.Name.Trim(),
            ContactNumber = request.ContactNumber.Trim(),
            Email = email,
            Role = "Doctor"
        };

        user.PasswordHash = _passwordHasher.HashPassword(user, request.Password);

        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetById), new { id = user.Id },
            new { user.Id, user.Name, user.Email, user.Role });
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        var user = await _context.Users
            .Where(user => user.Id == id)
            .Select(user => new
            {
                user.Id,
                user.Name,
                user.ContactNumber,
                user.Email,
                user.Role
            })
            .FirstOrDefaultAsync();

        if (user == null)
        {
            return NotFound();
        }

        return Ok(user);
    }

    [HttpGet]
    public async Task<IActionResult> GetDoctors()
    {
        var doctors = await _context.Users
            .Where(user => user.Role == "Doctor")
            .OrderBy(user => user.Name)
            .Select(user => new
            {
                user.Id,
                user.Name,
                user.Email,
                user.ContactNumber
            })
            .ToListAsync();

        return Ok(doctors);
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        string email = request.Email.Trim().ToLower();

        var user = await _context.Users
            .FirstOrDefaultAsync(user => user.Email == email);

        if (user == null)
        {
            return Unauthorized("Invalid email or password.");
        }

        var result = _passwordHasher.VerifyHashedPassword(
            user, user.PasswordHash, request.Password);

        if (result == PasswordVerificationResult.Failed)
        {
            return Unauthorized("Invalid email or password.");
        }

        // This simple case-study version returns the user details.
        // JWT authentication can be added as a separate improvement.
        return Ok(new
        {
            user.Id,
            user.Name,
            user.Email,
            user.Role
        });
    }
}

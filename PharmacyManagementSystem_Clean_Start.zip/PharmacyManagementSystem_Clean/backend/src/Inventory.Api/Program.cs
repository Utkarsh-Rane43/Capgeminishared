using Inventory.Api.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Register controllers and the Inventory database.
builder.Services.AddControllers();

builder.Services.AddDbContext<InventoryDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("Inventory")));

builder.Services.AddEndpointsApiExplorer();

var app = builder.Build();

app.MapControllers();

app.MapGet("/health", () => "Inventory API is running");

app.MapGet("/health/database", async (InventoryDbContext db) =>
{
    bool connected = await db.Database.CanConnectAsync();

    return connected
        ? Results.Ok("Inventory database connection successful.")
        : Results.Problem("Could not connect to the Inventory database.");
});

app.Run();

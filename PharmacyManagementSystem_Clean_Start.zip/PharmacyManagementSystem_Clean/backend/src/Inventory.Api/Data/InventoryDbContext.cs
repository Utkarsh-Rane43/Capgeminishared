using Inventory.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Api.Data;

public class InventoryDbContext : DbContext
{
    public InventoryDbContext(DbContextOptions<InventoryDbContext> options)
        : base(options)
    {
    }

    public DbSet<Drug> Drugs => Set<Drug>();
    public DbSet<Supplier> Suppliers => Set<Supplier>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Drug>().Property(drug => drug.Price).HasPrecision(10, 2);
        modelBuilder.Entity<Drug>().HasIndex(drug => drug.Name);
        modelBuilder.Entity<Supplier>().HasIndex(supplier => supplier.Email).IsUnique();
    }
}

namespace Inventory.Api.Models;

public class Drug
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public decimal Price { get; set; }
    public int Quantity { get; set; }
    public string Manufacturer { get; set; } = "";
}

using Inventory.Api.Data;
using Inventory.Api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DrugsController : ControllerBase
{
    private readonly InventoryDbContext _context;

    public DrugsController(InventoryDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var drugs = await _context.Drugs
            .OrderBy(drug => drug.Name)
            .ToListAsync();

        return Ok(drugs);
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        var drug = await _context.Drugs.FindAsync(id);

        if (drug == null)
        {
            return NotFound();
        }

        return Ok(drug);
    }

    [HttpPost]
    public async Task<IActionResult> Add(Drug drug)
    {
        if (drug.Price < 0 || drug.Quantity < 0)
        {
            return BadRequest("Price and quantity cannot be negative.");
        }

        _context.Drugs.Add(drug);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetById), new { id = drug.Id }, drug);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, Drug updatedDrug)
    {
        var drug = await _context.Drugs.FindAsync(id);

        if (drug == null)
        {
            return NotFound();
        }

        drug.Name = updatedDrug.Name;
        drug.Description = updatedDrug.Description;
        drug.Price = updatedDrug.Price;
        drug.Quantity = updatedDrug.Quantity;
        drug.Manufacturer = updatedDrug.Manufacturer;

        await _context.SaveChangesAsync();

        return Ok(drug);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var drug = await _context.Drugs.FindAsync(id);

        if (drug == null)
        {
            return NotFound();
        }

        _context.Drugs.Remove(drug);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}

using InventoryService.Models; using Microsoft.EntityFrameworkCore;
namespace InventoryService.Data;
public class InventoryDbContext(DbContextOptions<InventoryDbContext> o):DbContext(o){
 public DbSet<Drug> Drugs=>Set<Drug>(); public DbSet<Supplier> Suppliers=>Set<Supplier>();
 public DbSet<Inventory> Inventories=>Set<Inventory>(); public DbSet<StockReservation> Reservations=>Set<StockReservation>();
 protected override void OnModelCreating(ModelBuilder b){
  b.Entity<Drug>().Property(x=>x.SellingPrice).HasPrecision(12,2); b.Entity<Drug>().Property(x=>x.GstRate).HasPrecision(5,2);
  b.Entity<Inventory>().HasIndex(x=>x.DrugId).IsUnique(); b.Entity<StockReservation>().HasIndex(x=>new{x.OrderId,x.DrugId}).IsUnique();
 }
}

namespace InventoryService.Models;
public class Drug { public Guid Id {get;set;} public string Name {get;set;}=""; public string? GenericName {get;set;}
 public string? Strength {get;set;} public string? DosageForm {get;set;} public string? Manufacturer {get;set;}
 public decimal SellingPrice {get;set;} public decimal GstRate {get;set;}=5; public Guid? SupplierId {get;set;} public bool IsActive {get;set;}=true; }
public class Supplier { public Guid Id {get;set;} public string Name {get;set;}=""; public string? ContactPerson {get;set;} public string? Email {get;set;} public string? Phone {get;set;} }
public class Inventory { public Guid Id {get;set;} public Guid DrugId {get;set;} public int AvailableQuantity {get;set;} public int ReservedQuantity {get;set;} public int ReorderLevel {get;set;}=10; }
public class StockReservation { public Guid Id {get;set;} public Guid OrderId {get;set;} public Guid DrugId {get;set;} public int Quantity {get;set;} public string Status {get;set;}="Reserved"; }

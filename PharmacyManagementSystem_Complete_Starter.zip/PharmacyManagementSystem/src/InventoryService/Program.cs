using InventoryService.Data; using InventoryService.Models; using Microsoft.EntityFrameworkCore;
var builder=WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<InventoryDbContext>(o=>o.UseMySql(builder.Configuration.GetConnectionString("Default"),ServerVersion.AutoDetect(builder.Configuration.GetConnectionString("Default"))));
builder.Services.AddEndpointsApiExplorer(); builder.Services.AddSwaggerGen();
var app=builder.Build(); app.UseSwagger(); app.UseSwaggerUI();
app.MapGet("/health",()=>Results.Ok(new{service="InventoryService",status="healthy"}));
app.MapGet("/api/drugs",async(InventoryDbContext db)=>Results.Ok(await db.Drugs.Where(x=>x.IsActive).ToListAsync()));
app.MapGet("/api/drugs/{id:guid}",async(Guid id,InventoryDbContext db)=>await db.Drugs.FindAsync(id) is { } d?Results.Ok(d):Results.NotFound());
app.MapPost("/api/drugs",async(DrugRequest r,InventoryDbContext db)=>{
 if(string.IsNullOrWhiteSpace(r.Name)||r.SellingPrice<0||r.GstRate<0||r.GstRate>100)return Results.BadRequest();
 var d=new Drug{Id=Guid.NewGuid(),Name=r.Name,GenericName=r.GenericName,Strength=r.Strength,DosageForm=r.DosageForm,Manufacturer=r.Manufacturer,SellingPrice=r.SellingPrice,GstRate=r.GstRate,SupplierId=r.SupplierId};
 db.Drugs.Add(d);db.Inventories.Add(new Inventory{Id=Guid.NewGuid(),DrugId=d.Id,AvailableQuantity=r.InitialStock,ReorderLevel=10});await db.SaveChangesAsync();return Results.Created($"/api/drugs/{d.Id}",d);
});
app.MapGet("/api/suppliers",async(InventoryDbContext db)=>Results.Ok(await db.Suppliers.ToListAsync()));
app.MapPost("/api/suppliers",async(SupplierRequest r,InventoryDbContext db)=>{var s=new Supplier{Id=Guid.NewGuid(),Name=r.Name,ContactPerson=r.ContactPerson,Email=r.Email,Phone=r.Phone};db.Suppliers.Add(s);await db.SaveChangesAsync();return Results.Created($"/api/suppliers/{s.Id}",s);});
app.MapGet("/api/inventory/{drugId:guid}",async(Guid drugId,InventoryDbContext db)=>await db.Inventories.FirstOrDefaultAsync(x=>x.DrugId==drugId) is { } i?Results.Ok(i):Results.NotFound());
app.MapPost("/api/inventory/reservations",async(ReservationRequest r,InventoryDbContext db)=>{
 if(r.Quantity<=0)return Results.BadRequest(new{message="Quantity must be positive."});
 var old=await db.Reservations.FirstOrDefaultAsync(x=>x.OrderId==r.OrderId&&x.DrugId==r.DrugId);if(old!=null)return Results.Ok(old);
 var stock=await db.Inventories.FirstOrDefaultAsync(x=>x.DrugId==r.DrugId);if(stock==null||stock.AvailableQuantity-stock.ReservedQuantity<r.Quantity)return Results.Conflict(new{message="Insufficient stock."});
 stock.ReservedQuantity+=r.Quantity;var res=new StockReservation{Id=Guid.NewGuid(),OrderId=r.OrderId,DrugId=r.DrugId,Quantity=r.Quantity};db.Reservations.Add(res);await db.SaveChangesAsync();return Results.Ok(res);
});
app.MapPost("/api/inventory/reservations/{orderId:guid}/commit",async(Guid orderId,InventoryDbContext db)=>{
 var rows=await db.Reservations.Where(x=>x.OrderId==orderId&&x.Status=="Reserved").ToListAsync();if(rows.Count==0)return Results.NotFound();
 foreach(var r in rows){var s=await db.Inventories.FirstAsync(x=>x.DrugId==r.DrugId);s.ReservedQuantity-=r.Quantity;s.AvailableQuantity-=r.Quantity;r.Status="Committed";}await db.SaveChangesAsync();return Results.Ok(new{status="Committed"});
});
app.MapPost("/api/inventory/reservations/{orderId:guid}/release",async(Guid orderId,InventoryDbContext db)=>{
 var rows=await db.Reservations.Where(x=>x.OrderId==orderId&&x.Status=="Reserved").ToListAsync();foreach(var r in rows){var s=await db.Inventories.FirstAsync(x=>x.DrugId==r.DrugId);s.ReservedQuantity-=r.Quantity;r.Status="Released";}await db.SaveChangesAsync();return Results.Ok(new{status="Released"});
});
app.Run();
record DrugRequest(string Name,string? GenericName,string? Strength,string? DosageForm,string? Manufacturer,decimal SellingPrice,decimal GstRate,Guid? SupplierId,int InitialStock);
record SupplierRequest(string Name,string? ContactPerson,string? Email,string? Phone);
record ReservationRequest(Guid OrderId,Guid DrugId,int Quantity);

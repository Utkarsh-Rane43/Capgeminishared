namespace Shared.Contracts;

public record PaymentSucceeded(
    Guid EventId, DateTime OccurredAtUtc, Guid PaymentId, Guid OrderId,
    decimal Amount, string Currency, Guid InvoiceId);

public record PaymentFailed(
    Guid EventId, DateTime OccurredAtUtc, Guid PaymentId, Guid OrderId,
    decimal Amount, string ReasonCode);

public record SaleCompleted(
    Guid EventId, DateTime OccurredAtUtc, Guid OrderId, decimal TotalAmount,
    string Currency, IReadOnlyList<SaleItem> Items);

public record SaleItem(Guid DrugId, string DrugName, int Quantity, decimal UnitPrice, decimal LineTotal);

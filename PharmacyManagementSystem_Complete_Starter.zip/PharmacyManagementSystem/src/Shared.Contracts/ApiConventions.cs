namespace Shared.Contracts;
public static class ApiConventions
{
    public static IResult NotFoundIfNull<T>(T? value) =>
        value is null ? Results.NotFound() : Results.Ok(value);
}

using Microsoft.EntityFrameworkCore;using PaymentService.Data;using PaymentService.Models;using QuestPDF.Fluent;using QuestPDF.Helpers;using QuestPDF.Infrastructure;
var b=WebApplication.CreateBuilder(args);b.Services.AddDbContext<PaymentDbContext>(o=>o.UseMySql(b.Configuration.GetConnectionString("Default"),ServerVersion.AutoDetect(b.Configuration.GetConnectionString("Default"))));
b.Services.AddEndpointsApiExplorer();b.Services.AddSwaggerGen();var app=b.Build();app.UseSwagger();app.UseSwaggerUI();QuestPDF.Settings.License=LicenseType.Community;
app.MapGet("/health",()=>Results.Ok(new{service="PaymentService",status="healthy"}));
app.MapPost("/api/payments/process",async(PaymentRequest req,PaymentDbContext db,IConfiguration cfg)=>{
 if(req.Amount<=0||string.IsNullOrWhiteSpace(req.IdempotencyKey))return Results.BadRequest();
 var old=await db.Payments.FirstOrDefaultAsync(x=>x.IdempotencyKey==req.IdempotencyKey);if(old!=null)return Results.Ok(old);
 var success=string.Equals(cfg["PaymentSimulation:Outcome"]??"Success","Success",StringComparison.OrdinalIgnoreCase);
 var p=new Payment{Id=Guid.NewGuid(),OrderId=req.OrderId,Amount=req.Amount,Currency=req.Currency??"INR",Method=req.Method??"UPI-Simulated",Status=success?"Succeeded":"Failed",TransactionReference=$"SIM-{Guid.NewGuid():N}",IdempotencyKey=req.IdempotencyKey};
 db.Payments.Add(p);await db.SaveChangesAsync();
 Invoice? invoice=null;
 if(success){invoice=new Invoice{Id=Guid.NewGuid(),PaymentId=p.Id,OrderId=p.OrderId,InvoiceNumber=$"INV-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid().ToString("N")[..8].ToUpper()}",Subtotal=req.Subtotal,GstAmount=req.GstAmount,TotalAmount=req.Amount};db.Invoices.Add(invoice);await db.SaveChangesAsync();}
 return Results.Ok(new{payment=p,invoice});
});
app.MapGet("/api/payments/{id:guid}",async(Guid id,PaymentDbContext db)=>await db.Payments.FindAsync(id) is{} p?Results.Ok(p):Results.NotFound());
app.MapGet("/api/invoices/{id:guid}/pdf",async(Guid id,PaymentDbContext db)=>{
 var inv=await db.Invoices.FindAsync(id);if(inv==null)return Results.NotFound();
 var bytes=Document.Create(c=>c.Page(page=>{page.Margin(40);page.Header().Text("PHARMACY TAX INVOICE").FontSize(20).Bold();page.Content().Column(col=>{col.Item().Text($"Invoice: {inv.InvoiceNumber}");col.Item().Text($"Order: {inv.OrderId}");col.Item().Text($"Date (UTC): {inv.InvoiceDateUtc:yyyy-MM-dd HH:mm}");col.Item().PaddingTop(20).Text($"Subtotal: INR {inv.Subtotal:0.00}");col.Item().Text($"GST: INR {inv.GstAmount:0.00}");col.Item().Text($"Total: INR {inv.TotalAmount:0.00}").Bold();});page.Footer().AlignCenter().Text("Payment simulated for project demonstration.");})).GeneratePdf();
 return Results.File(bytes,"application/pdf",$"{inv.InvoiceNumber}.pdf");
});
app.Run();
record PaymentRequest(Guid OrderId,decimal Amount,decimal Subtotal,decimal GstAmount,string? Currency,string? Method,string IdempotencyKey);

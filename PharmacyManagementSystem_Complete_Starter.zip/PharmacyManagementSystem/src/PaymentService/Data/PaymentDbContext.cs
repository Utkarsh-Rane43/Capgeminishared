using Microsoft.EntityFrameworkCore;using PaymentService.Models;
namespace PaymentService.Data;
public class PaymentDbContext(DbContextOptions<PaymentDbContext> o):DbContext(o){public DbSet<Payment> Payments=>Set<Payment>();public DbSet<Invoice> Invoices=>Set<Invoice>();protected override void OnModelCreating(ModelBuilder b){b.Entity<Payment>().HasIndex(x=>x.IdempotencyKey).IsUnique();b.Entity<Invoice>().HasIndex(x=>x.InvoiceNumber).IsUnique();b.Entity<Payment>().Property(x=>x.Amount).HasPrecision(12,2);b.Entity<Invoice>().Property(x=>x.TotalAmount).HasPrecision(12,2);}}

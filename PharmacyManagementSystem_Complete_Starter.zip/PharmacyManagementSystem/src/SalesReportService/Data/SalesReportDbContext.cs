using Microsoft.EntityFrameworkCore;using SalesReportService.Models;
namespace SalesReportService.Data;
public class SalesReportDbContext(DbContextOptions<SalesReportDbContext> o):DbContext(o){public DbSet<SalesReport> Reports=>Set<SalesReport>();public DbSet<SaleRecord> Sales=>Set<SaleRecord>();protected override void OnModelCreating(ModelBuilder b){b.Entity<SaleRecord>().HasIndex(x=>x.EventId).IsUnique();b.Entity<SaleRecord>().Property(x=>x.TotalAmount).HasPrecision(12,2);b.Entity<SalesReport>().Property(x=>x.TotalSales).HasPrecision(14,2);}}

using Microsoft.EntityFrameworkCore;using SalesReportService.Data;
var b=WebApplication.CreateBuilder(args);b.Services.AddDbContext<SalesReportDbContext>(o=>o.UseMySql(b.Configuration.GetConnectionString("Default"),ServerVersion.AutoDetect(b.Configuration.GetConnectionString("Default"))));
b.Services.AddEndpointsApiExplorer();b.Services.AddSwaggerGen();var app=b.Build();app.UseSwagger();app.UseSwaggerUI();
app.MapGet("/health",()=>Results.Ok(new{service="SalesReportService",status="healthy"}));
app.MapGet("/api/reports/daily",async(DateOnly? date,SalesReportDbContext db)=>{
 var d=date??DateOnly.FromDateTime(DateTime.UtcNow);var start=d.ToDateTime(TimeOnly.MinValue,DateTimeKind.Utc);var end=start.AddDays(1);
 var sales=await db.Sales.Where(x=>x.OccurredAtUtc>=start&&x.OccurredAtUtc<end).ToListAsync();
 return Results.Ok(new{date=d,totalSales=sales.Sum(x=>x.TotalAmount),successfulOrders=sales.Count,averageOrderValue=sales.Count==0?0:sales.Average(x=>x.TotalAmount)});
});
app.MapGet("/api/reports/monthly",async(int year,int month,SalesReportDbContext db)=>{
 if(month<1||month>12)return Results.BadRequest();var start=new DateTime(year,month,1,0,0,0,DateTimeKind.Utc);var end=start.AddMonths(1);
 var sales=await db.Sales.Where(x=>x.OccurredAtUtc>=start&&x.OccurredAtUtc<end).ToListAsync();
 return Results.Ok(new{year,month,totalSales=sales.Sum(x=>x.TotalAmount),successfulOrders=sales.Count,averageOrderValue=sales.Count==0?0:sales.Average(x=>x.TotalAmount)});
});
app.Run();

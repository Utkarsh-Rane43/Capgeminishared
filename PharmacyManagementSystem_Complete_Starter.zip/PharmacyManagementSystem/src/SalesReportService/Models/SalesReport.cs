namespace SalesReportService.Models;
public class SalesReport { public Guid Id{get;set;} public string ReportType{get;set;}="Daily"; public DateTime PeriodStartUtc{get;set;} public DateTime PeriodEndUtc{get;set;} public int SuccessfulOrderCount{get;set;} public decimal TotalSales{get;set;} public decimal AverageOrderValue{get;set;} public DateTime GeneratedAtUtc{get;set;}=DateTime.UtcNow; }
public class SaleRecord { public Guid Id{get;set;} public Guid EventId{get;set;} public Guid OrderId{get;set;} public decimal TotalAmount{get;set;} public DateTime OccurredAtUtc{get;set;} }

namespace AuthService.Models;
public class User {
 public Guid Id { get; set; } public string FullName { get; set; } = "";
 public string Email { get; set; } = ""; public string PasswordHash { get; set; } = "";
 public int RoleId { get; set; } public Role Role { get; set; } = null!;
 public bool IsActive { get; set; } = true; public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}
public class Role { public int Id { get; set; } public string Name { get; set; } = ""; public List<User> Users { get; set; } = []; }

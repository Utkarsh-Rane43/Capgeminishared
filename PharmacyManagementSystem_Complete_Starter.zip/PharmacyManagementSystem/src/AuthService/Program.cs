using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using AuthService.Data;
using AuthService.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<AuthDbContext>(o =>
    o.UseMySql(builder.Configuration.GetConnectionString("Default"),
        ServerVersion.AutoDetect(builder.Configuration.GetConnectionString("Default"))));
builder.Services.AddScoped<IPasswordHasher<User>, PasswordHasher<User>>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
var app = builder.Build();
app.UseSwagger(); app.UseSwaggerUI();

app.MapGet("/health", () => Results.Ok(new { service = "AuthService", status = "healthy" }));
app.MapPost("/api/auth/register", async (RegisterRequest req, AuthDbContext db, IPasswordHasher<User> hasher) =>
{
    if (string.IsNullOrWhiteSpace(req.Email) || string.IsNullOrWhiteSpace(req.Password) || req.Password.Length < 8)
        return Results.BadRequest(new { message = "Valid email and password of at least 8 characters are required." });
    var email = req.Email.Trim().ToLowerInvariant();
    if (await db.Users.AnyAsync(x => x.Email == email)) return Results.Conflict(new { message = "Email already exists." });
    var role = await db.Roles.FirstOrDefaultAsync(x => x.Name == "Doctor"); // Public registration can never create an Admin.
    if (role is null) return Results.Problem("Roles have not been seeded. Run the AuthDB SQL script.");
    var user = new User { Id = Guid.NewGuid(), FullName = req.FullName.Trim(), Email = email, RoleId = role.Id, IsActive = true };
    user.PasswordHash = hasher.HashPassword(user, req.Password);
    db.Users.Add(user); await db.SaveChangesAsync();
    return Results.Created($"/api/users/{user.Id}", new { user.Id, user.FullName, user.Email, Role = role.Name });
});
app.MapPost("/api/auth/login", async (LoginRequest req, AuthDbContext db, IPasswordHasher<User> hasher, IConfiguration config) =>
{
    var user = await db.Users.Include(x => x.Role).FirstOrDefaultAsync(x => x.Email == req.Email.ToLower());
    if (user is null || !user.IsActive || hasher.VerifyHashedPassword(user, user.PasswordHash, req.Password) == PasswordVerificationResult.Failed)
        return Results.Unauthorized();
    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Key"]!));
    var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
    var claims = new[] { new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()), new Claim(ClaimTypes.Name, user.FullName),
        new Claim(ClaimTypes.Email, user.Email), new Claim(ClaimTypes.Role, user.Role.Name) };
    var token = new JwtSecurityToken(config["Jwt:Issuer"], config["Jwt:Audience"], claims,
        expires: DateTime.UtcNow.AddHours(4), signingCredentials: creds);
    return Results.Ok(new { accessToken = new JwtSecurityTokenHandler().WriteToken(token), expiresInSeconds = 14400,
        user = new { user.Id, user.FullName, user.Email, role = user.Role.Name } });
});
app.MapGet("/api/users", async (AuthDbContext db) => Results.Ok(await db.Users.Include(x => x.Role)
    .Select(x => new { x.Id, x.FullName, x.Email, Role = x.Role.Name, x.IsActive }).ToListAsync()));
app.Run();

record RegisterRequest(string FullName, string Email, string Password, string? Role);
record LoginRequest(string Email, string Password);

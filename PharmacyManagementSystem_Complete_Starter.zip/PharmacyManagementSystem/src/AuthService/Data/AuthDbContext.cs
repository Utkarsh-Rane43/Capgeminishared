using AuthService.Models;
using Microsoft.EntityFrameworkCore;
namespace AuthService.Data;
public class AuthDbContext(DbContextOptions<AuthDbContext> options) : DbContext(options) {
 public DbSet<User> Users => Set<User>(); public DbSet<Role> Roles => Set<Role>();
 protected override void OnModelCreating(ModelBuilder b) {
  b.Entity<Role>().HasIndex(x=>x.Name).IsUnique();
  b.Entity<User>().HasIndex(x=>x.Email).IsUnique();
  b.Entity<User>().HasOne(x=>x.Role).WithMany(x=>x.Users).HasForeignKey(x=>x.RoleId);
  b.Entity<Role>().HasData(new Role{Id=1,Name="Admin"},new Role{Id=2,Name="Doctor"});
 }
}

using System.Net.Http.Json;using Microsoft.EntityFrameworkCore;using OrderService.Data;using OrderService.Models;
var b=WebApplication.CreateBuilder(args);b.Services.AddDbContext<OrderDbContext>(o=>o.UseMySql(b.Configuration.GetConnectionString("Default"),ServerVersion.AutoDetect(b.Configuration.GetConnectionString("Default"))));
b.Services.AddHttpClient("inventory",c=>c.BaseAddress=new Uri(b.Configuration["Services:Inventory"]!));
b.Services.AddEndpointsApiExplorer();b.Services.AddSwaggerGen();var app=b.Build();app.UseSwagger();app.UseSwaggerUI();
app.MapGet("/health",()=>Results.Ok(new{service="OrderService",status="healthy"}));
app.MapGet("/api/orders",async(OrderDbContext db)=>Results.Ok(await db.Orders.Include(x=>x.Items).OrderByDescending(x=>x.CreatedAtUtc).ToListAsync()));
app.MapGet("/api/orders/{id:guid}",async(Guid id,OrderDbContext db)=>await db.Orders.Include(x=>x.Items).FirstOrDefaultAsync(x=>x.Id==id) is { } o?Results.Ok(o):Results.NotFound());
app.MapPost("/api/orders",async(CreateOrderRequest req,OrderDbContext db,IHttpClientFactory factory)=>{
 if(req.Items.Count==0||req.Items.Any(x=>x.Quantity<=0))return Results.BadRequest(new{message="At least one item with positive quantity is required."});
 var client=factory.CreateClient("inventory");var order=new Order{Id=Guid.NewGuid(),UserId=req.UserId};
 foreach(var line in req.Items){
  var drug=await client.GetFromJsonAsync<DrugDto>($"/api/drugs/{line.DrugId}");if(drug==null||!drug.IsActive)return Results.BadRequest(new{message=$"Drug {line.DrugId} is unavailable."});
  var stock=await client.GetFromJsonAsync<InventoryDto>($"/api/inventory/{line.DrugId}");if(stock==null||stock.AvailableQuantity-stock.ReservedQuantity<line.Quantity)return Results.Conflict(new{message=$"Insufficient stock for {drug.Name}."});
  var subtotal=drug.SellingPrice*line.Quantity;var gst=Math.Round(subtotal*drug.GstRate/100m,2);
  order.Items.Add(new OrderItem{Id=Guid.NewGuid(),DrugId=drug.Id,DrugNameSnapshot=drug.Name,UnitPriceSnapshot=drug.SellingPrice,GstRateSnapshot=drug.GstRate,Quantity=line.Quantity,LineSubtotal=subtotal,GstAmount=gst,LineTotal=subtotal+gst});
 }
 order.Subtotal=order.Items.Sum(x=>x.LineSubtotal);order.GstAmount=order.Items.Sum(x=>x.GstAmount);order.TotalAmount=order.Subtotal+order.GstAmount;
 foreach(var item in order.Items){var response=await client.PostAsJsonAsync("/api/inventory/reservations",new{orderId=order.Id,drugId=item.DrugId,quantity=item.Quantity});if(!response.IsSuccessStatusCode){await client.PostAsync($"/api/inventory/reservations/{order.Id}/release",null);return Results.Conflict(new{message="Could not reserve all stock."});}}
 db.Orders.Add(order);await db.SaveChangesAsync();return Results.Created($"/api/orders/{order.Id}",order);
});
app.Run();
record CreateOrderRequest(Guid UserId,List<CreateOrderItem> Items);record CreateOrderItem(Guid DrugId,int Quantity);
record DrugDto(Guid Id,string Name,decimal SellingPrice,decimal GstRate,bool IsActive);
record InventoryDto(Guid Id,Guid DrugId,int AvailableQuantity,int ReservedQuantity,int ReorderLevel);

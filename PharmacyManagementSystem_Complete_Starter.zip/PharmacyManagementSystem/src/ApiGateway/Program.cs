var builder=WebApplication.CreateBuilder(args);
builder.Services.AddReverseProxy().LoadFromConfig(builder.Configuration.GetSection("ReverseProxy"));
var app=builder.Build();
app.MapGet("/health",()=>Results.Ok(new{service="ApiGateway",status="healthy"}));
app.MapReverseProxy();
app.Run();

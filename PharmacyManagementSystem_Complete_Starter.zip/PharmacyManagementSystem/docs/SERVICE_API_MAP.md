# API map

## AuthService
- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/users`
- GET `/health`

## InventoryService
- GET/POST `/api/drugs`
- GET `/api/drugs/{id}`
- GET/POST `/api/suppliers`
- GET `/api/inventory/{drugId}`
- POST `/api/inventory/reservations`
- POST `/api/inventory/reservations/{orderId}/commit`
- POST `/api/inventory/reservations/{orderId}/release`

## OrderService
- POST `/api/orders`
- GET `/api/orders`
- GET `/api/orders/{id}`

## PaymentService
- POST `/api/payments/process`
- GET `/api/payments/{id}`
- GET `/api/invoices/{id}/pdf`

## SalesReportService
- GET `/api/reports/daily?date=YYYY-MM-DD`
- GET `/api/reports/monthly?year=YYYY&month=MM`

All routes are also mapped through YARP Gateway at `http://localhost:5000`.

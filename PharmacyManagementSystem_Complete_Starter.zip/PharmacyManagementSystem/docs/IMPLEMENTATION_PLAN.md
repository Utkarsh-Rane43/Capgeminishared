# Implementation plan

## Milestone 1 — Environment and first build
- Install .NET 10, MySQL 8+, Node LTS.
- Update local DB credentials.
- Run `dotnet restore` and `dotnet build`.
- Fix any package/provider version compatibility for the installed .NET 10 SDK.
- Start each service and confirm `/health` and `/swagger`.

## Milestone 2 — Auth
- Verify Roles seed.
- Register Admin/Doctor and test login.
- Add JWT bearer validation and authorization policies to all services.
- Restrict registration so public callers cannot self-assign Admin.

## Milestone 3 — Inventory
- Apply migrations/schema.
- Add supplier and drug validation.
- Add concurrency-safe stock reservation transactions.
- Test reserve/commit/release and duplicate requests.

## Milestone 4 — Orders
- Add proper service-to-service authentication.
- Make order creation transactional within OrderDB.
- Add compensation when any reservation fails.
- Add payment initiation endpoint and state transitions.

## Milestone 5 — Payment
- Keep simulator outcome in configuration: `Success` or `Failure`.
- Enforce idempotency under concurrent requests.
- Generate PDF invoice only on successful payment.
- Add invoice details and line items to PDF.
- Publish payment outcome event.

## Milestone 6 — Messaging and reporting
- Add RabbitMQ publisher/consumer implementations.
- Use durable queues, acknowledgements, retry/dead-letter strategy.
- Deduplicate by EventId.
- Publish SaleCompleted only after payment success and order confirmation.
- SalesReportService consumes events and persists sale records.
- Add weekly report endpoint and top-selling medicine aggregates.

## Milestone 7 — Gateway and Angular
- Verify all YARP routes.
- Add CORS for Angular origin.
- Add Angular login, role-based screens, API services and error states.
- Route Angular traffic through Gateway only.

## Milestone 8 — End-to-end testing
- Successful order: reserve stock → simulated payment success → invoice PDF → stock commit → report includes sale.
- Failed order: simulated payment failure → release stock → no paid invoice → no sale report.
- Duplicate payment request: one payment only.
- Unauthorized access: reject.
- Service unavailable: clear error and safe retry.

## GST rule
The current starter calculates GST as `line subtotal × GST rate / 100`. The applicable GST rate, inclusive/exclusive pricing, HSN/SAC, place-of-supply and invoice compliance need to be confirmed for the intended pharmacy/business scenario before treating generated invoices as tax-compliant.

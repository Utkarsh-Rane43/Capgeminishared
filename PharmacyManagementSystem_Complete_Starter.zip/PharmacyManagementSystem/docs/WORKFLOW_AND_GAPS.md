# Business workflow and current integration gaps

## Intended successful flow
1. Doctor authenticates with AuthService.
2. Angular submits DrugId and quantity to OrderService.
3. OrderService obtains authoritative drug price/GST and stock from InventoryService.
4. OrderService stores order and items, then reserves inventory.
5. PaymentService simulates payment based on `PaymentSimulation:Outcome`.
6. On success, PaymentService creates a payment and PDF invoice.
7. Payment outcome event is published; OrderService confirms the order and InventoryService commits stock.
8. SalesReportService consumes a SaleCompleted event and updates reporting data.

## Intended failed flow
- PaymentService stores failed payment.
- Order remains PaymentFailed.
- Inventory reservation is released.
- No invoice is issued as paid and no sale is counted.

## Current scaffold limitations
- Payment API currently creates payment/invoice, but does not yet publish RabbitMQ events.
- SalesReport API reads its own SaleRecords, but event consumer is not yet wired.
- Order API creates pending orders and reserves stock, but payment initiation and state transitions are not yet wired.
- Auth login issues JWT, but downstream JWT validation/authorization is a required next milestone.
- Order API's multi-item reservation needs a robust compensation transaction for partial failure.
- PDF currently provides a basic invoice summary; add seller/buyer details and item lines before final demo.

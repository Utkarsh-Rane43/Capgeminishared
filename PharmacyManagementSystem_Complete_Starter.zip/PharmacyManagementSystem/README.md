# Pharmacy Management System — Five Microservices

A .NET 10 / ASP.NET Core / EF Core / MySQL microservices starter workspace.

## Architecture
- AuthService — Users, Roles, registration and JWT login
- InventoryService — Drugs, Suppliers, Inventory and stock reservations
- OrderService — Orders, OrderItems and GST snapshot calculations
- PaymentService — configurable simulated payment and PDF invoice
- SalesReportService — daily and monthly sales summaries
- ApiGateway — YARP reverse proxy routing all service APIs
- Angular frontend — starter setup instructions and endpoint map
- Shared.Contracts — event contract definitions

Each service owns its own MySQL database. No cross-database foreign keys are used.

## Important status
This is a runnable-oriented starter scaffold, not a fully integrated/production-ready system. Core API foundations are present. The complete RabbitMQ publisher/consumer wiring, order-to-payment orchestration, JWT validation/authorization across every service, Angular screens, migrations, and robust saga/outbox/retry handling remain implementation milestones. Follow `docs/IMPLEMENTATION_PLAN.md`.

## Requirements
- .NET 10 SDK
- MySQL 8+
- Node.js LTS and Angular CLI (for frontend)
- Visual Studio 2022 recent version or VS Code

## Database setup
1. Create the five databases using `database/01_AuthDB.sql` through `05_SalesReportDB.sql`.
2. Update each service's `appsettings.json` connection string. Do not commit real credentials.
3. Run EF Core migrations or align the schema with the SQL scripts. Do not use both approaches blindly against the same existing tables.

## Build
From repository root:
```powershell
dotnet restore
dotnet build
```

## Run services (separate terminals)
```powershell
dotnet run --project src/AuthService --urls http://localhost:5001
dotnet run --project src/InventoryService --urls http://localhost:5002
dotnet run --project src/OrderService --urls http://localhost:5003
dotnet run --project src/PaymentService --urls http://localhost:5004
dotnet run --project src/SalesReportService --urls http://localhost:5005
dotnet run --project src/ApiGateway --urls http://localhost:5000
```
Swagger is exposed by each service at `/swagger`. Gateway health is `/health`.

## Security warnings
- Replace the development JWT key before use.
- Restrict user registration/role assignment to trusted Admin workflows before deployment.
- Add JWT validation and role authorization to all protected services.
- Do not accept real card/UPI credentials. Payment is a simulation only.
- GST rates and tax treatment must be validated against the business's applicable tax rules; configurable rates are not tax advice.

# Angular frontend starter

Create the Angular application with:
```powershell
cd frontend
npx @angular/cli@latest new pharmacy-ui --routing --style=scss
```
Then configure API base URL to `http://localhost:5000` (YARP gateway).
Suggested screens: Login, Admin Dashboard, Doctor Dashboard, Drugs, Suppliers, Inventory, Orders, Payments/Invoice, Sales Reports.
Use Angular route guards for UX only; backend authorization remains mandatory.

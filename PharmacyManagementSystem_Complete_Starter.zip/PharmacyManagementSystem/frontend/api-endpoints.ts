// Reference endpoints; configure Angular HttpClient services to use these through the gateway.
export const API = {
  auth: '/api/auth',
  users: '/api/users',
  drugs: '/api/drugs',
  suppliers: '/api/suppliers',
  inventory: '/api/inventory',
  orders: '/api/orders',
  payments: '/api/payments',
  invoices: '/api/invoices',
  reports: '/api/reports'
};

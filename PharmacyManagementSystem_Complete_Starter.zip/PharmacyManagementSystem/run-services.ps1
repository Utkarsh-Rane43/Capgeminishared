$ErrorActionPreference = "Stop"
Start-Process powershell -ArgumentList '-NoExit','-Command','dotnet run --project src/AuthService --urls http://localhost:5001'
Start-Process powershell -ArgumentList '-NoExit','-Command','dotnet run --project src/InventoryService --urls http://localhost:5002'
Start-Process powershell -ArgumentList '-NoExit','-Command','dotnet run --project src/OrderService --urls http://localhost:5003'
Start-Process powershell -ArgumentList '-NoExit','-Command','dotnet run --project src/PaymentService --urls http://localhost:5004'
Start-Process powershell -ArgumentList '-NoExit','-Command','dotnet run --project src/SalesReportService --urls http://localhost:5005'
Start-Process powershell -ArgumentList '-NoExit','-Command','dotnet run --project src/ApiGateway --urls http://localhost:5000'

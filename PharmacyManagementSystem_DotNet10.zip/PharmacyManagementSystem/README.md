# Pharmacy Management System (.NET 10)

A microservices-based pharmacy case study implementation using ASP.NET Core Web API, EF Core, MySQL, Angular and RabbitMQ.

## Architecture
- `Users.Api`: doctor registration/login, JWT issuance, admin user management.
- `Inventory.Api`: drug and supplier catalogue, stock balances, adjustments, sales reports.
- `Orders.Api`: doctor orders, admin review, order history and outbox records.
- `Pharmacy.Gateway`: YARP reverse proxy; Angular uses the gateway at `http://localhost:5080`.
- Each service owns its database. Cross-service identifiers are references, not cross-database foreign keys.

## Prerequisites
- .NET 10 SDK
- Node.js 22+ and npm
- MySQL 8.x
- RabbitMQ 4.x (messaging worker integration is a subsequent milestone)

## Configure MySQL
Edit each API's `appsettings.json` ConnectionStrings. Use a separate MySQL schema for each service. Run scripts in `database/` in numeric order. Keep credentials and JWT secrets out of source control in real deployments; use environment variables or .NET User Secrets.

Set the same strong JWT key in all four `appsettings.json` files under `Jwt:Key`. Use at least 32 random characters. This is a development placeholder, not a production secret.

## Run backend (four terminals)
From repository root:
```powershell
 dotnet restore ./backend/PharmacyManagement.sln
 dotnet build ./backend/PharmacyManagement.sln
 dotnet run --project ./backend/src/Users/Users.Api --urls http://localhost:5101
 dotnet run --project ./backend/src/Inventory/Inventory.Api --urls http://localhost:5102
 dotnet run --project ./backend/src/Orders/Orders.Api --urls http://localhost:5103
 dotnet run --project ./backend/src/Gateway/Pharmacy.Gateway --urls http://localhost:5080
```

Swagger is available at each API's `/swagger` in Development. Health endpoints: `/health`.

## Run Angular
```powershell
cd frontend/pharmacy-ui
npm install
npm start
```
Open `http://localhost:4200`.

## Current implementation boundary
This is the initial end-to-end source baseline, not yet a production-ready application. The initial milestone includes service projects, authentication endpoints, catalogue/supplier/stock/report endpoints, order endpoints, gateway routing, Angular pages, SQL schema scripts and an Orders Outbox table. Before calling the workflow complete, we still need to implement and test: inventory reservation ledger with idempotent reserve/release/consume; authoritative server-side price resolution in order creation; full Orders-to-Inventory service client; RabbitMQ publisher/consumer, Inbox, retry and DLQ; admin bootstrap provisioning; complete Angular CRUD/order forms and role guards; automated tests; migrations; PDF/CSV export; and end-to-end verification.

## Security notes
- Public signup always creates a DOCTOR. Admin provisioning must be done out-of-band.
- Protect internal service endpoints with a rotated secret and constant-time validation before enabling them; do not expose them publicly.
- Configure HTTPS, CORS, rate limiting, secret storage, logging and backups before deployment.

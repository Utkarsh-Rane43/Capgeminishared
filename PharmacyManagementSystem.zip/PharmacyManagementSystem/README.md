# Pharmacy Management System

A learning/demo microservices implementation: Angular 18, ASP.NET Core 9 Web APIs, EF Core + MySQL, JWT, RabbitMQ.

## Services
- `Users.Api` — doctor registration, login, JWT, controlled admin bootstrap.
- `SupplierInventory.Api` — drugs, suppliers, stock, reservations, sales reports.
- `Orders.Api` — order placement, doctor history, admin verify/reject/pickup.
- `frontend/pharmacy-ui` — Angular admin/doctor application.

Each API owns its own MySQL database. IDs crossing services are references, not cross-database foreign keys.

## Prerequisites
.NET 9 SDK, Node.js 18.19+ (or 20 LTS), npm, Docker Desktop with Compose. The included `docker-compose.yml` runs MySQL and RabbitMQ. If Docker isn't available, install MySQL 8 and RabbitMQ separately and update connection strings.

## Run (Windows CMD)
1. Start dependencies from repository root:
   `docker compose up -d`
2. In three separate terminals:
   `dotnet run --project src/Users.Api`
   `dotnet run --project src/SupplierInventory.Api`
   `dotnet run --project src/Orders.Api`
3. In another terminal:
   `cd frontend/pharmacy-ui`
   `npm install`
   `npm start`
4. Open `http://localhost:4200`.

APIs: Users `http://localhost:5101`, Inventory `http://localhost:5102`, Orders `http://localhost:5103`; Swagger at `/swagger`.

## First admin
Set `AdminBootstrap__Email`, `AdminBootstrap__Password`, `AdminBootstrap__Name` environment variables before starting Users.Api. The bootstrap endpoint is disabled unless these are set. Example CMD:
`set AdminBootstrap__Email=admin@pharmacy.local`
`set AdminBootstrap__Password=ChangeThis!12345`
`set AdminBootstrap__Name=Pharmacy Admin`
Then start Users.Api. The admin account is created once if it does not exist. Do not use these demo credentials in production.

## Demo workflow
1. Register a doctor through the UI or `POST /api/v1/users/register`.
2. Login and copy the returned JWT; UI stores it in sessionStorage for this demo.
3. Login as admin using the bootstrap credentials.
4. Add a drug and initial stock from Inventory Swagger (`POST /api/v1/drugs`).
5. Doctor adds items and submits an order.
6. Admin verifies; Inventory reserves stock. Admin confirms pickup; Inventory deducts stock and records a sale.

## Important implementation notes
- EF Core `EnsureCreated` is used for frictionless local demo startup. For a real deployment, replace it with reviewed EF Core migrations per service.
- The order flow calls the Inventory API for reserve/finalize/release. RabbitMQ is provisioned and a durable event publisher is included in Orders; the HTTP call is the synchronous consistency path in this starter. A production-grade outbox/inbox + saga should replace this simplified orchestration.
- Admin role cannot be self-selected during public registration.
- This is a starter/reference project, not a production pharmacy dispensing system. Add prescription validation, audit/compliance controls, TLS, secrets vault, backups, monitoring, rate limits and formal security review before real use.

## Build and tests
`dotnet restore PharmacyManagementSystem.sln`
`dotnet build PharmacyManagementSystem.sln`
`dotnet test PharmacyManagementSystem.sln`

If package restore fails, check internet access and SDK version with `dotnet --list-sdks`.

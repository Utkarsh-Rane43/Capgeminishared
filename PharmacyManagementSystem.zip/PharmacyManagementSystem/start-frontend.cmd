@echo off
cd /d "%~dp0frontend\pharmacy-ui"
npm install
npm start

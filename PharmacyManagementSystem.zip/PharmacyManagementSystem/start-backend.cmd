@echo off
start "Users API" cmd /k dotnet run --project src/Users.Api
start "Inventory API" cmd /k dotnet run --project src/SupplierInventory.Api
start "Orders API" cmd /k dotnet run --project src/Orders.Api

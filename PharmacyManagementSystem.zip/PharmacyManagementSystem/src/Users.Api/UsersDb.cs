using Microsoft.EntityFrameworkCore;
namespace Users.Api;
public class AppUser { public long Id{get;set;} public string Name{get;set;}=""; public string Email{get;set;}=""; public string? Contact{get;set;} public string PasswordHash{get;set;}=""; public string Role{get;set;}="DOCTOR"; public bool IsActive{get;set;}=true; public DateTime CreatedAtUtc{get;set;}=DateTime.UtcNow; }
public class UsersDb(DbContextOptions<UsersDb> options):DbContext(options){public DbSet<AppUser> Users=>Set<AppUser>(); protected override void OnModelCreating(ModelBuilder b){b.Entity<AppUser>().HasIndex(x=>x.Email).IsUnique();b.Entity<AppUser>().Property(x=>x.Email).HasMaxLength(254);}}

using Microsoft.EntityFrameworkCore;
using Pharmacy.Shared;
using Users.Api;
var builder=WebApplication.CreateBuilder(args);
builder.Services.AddControllers(); builder.Services.AddEndpointsApiExplorer(); builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<UsersDb>(o=>o.UseMySql(builder.Configuration.GetConnectionString("Default"),ServerVersion.AutoDetect(builder.Configuration.GetConnectionString("Default"))));
builder.Services.AddJwt(builder.Configuration); builder.Services.AddCors(o=>o.AddDefaultPolicy(p=>p.WithOrigins("http://localhost:4200").AllowAnyHeader().AllowAnyMethod()));
var app=builder.Build(); app.UseCors(); app.UseSwagger(); app.UseSwaggerUI(); app.UseAuthentication(); app.UseAuthorization(); app.MapControllers();
using(var scope=app.Services.CreateScope()){var db=scope.ServiceProvider.GetRequiredService<UsersDb>(); await db.Database.EnsureCreatedAsync(); var cfg=scope.ServiceProvider.GetRequiredService<IConfiguration>(); var email=cfg["AdminBootstrap:Email"]; var pass=cfg["AdminBootstrap:Password"]; if(!string.IsNullOrWhiteSpace(email)&&!string.IsNullOrWhiteSpace(pass)&&!await db.Users.AnyAsync(x=>x.Email==email.ToLower())){var u=new AppUser{Name=cfg["AdminBootstrap:Name"]??"Administrator",Email=email.ToLower(),Role="ADMIN"};u.PasswordHash=new Microsoft.AspNetCore.Identity.PasswordHasher<AppUser>().HashPassword(u,pass);db.Users.Add(u);await db.SaveChangesAsync();}}
app.MapGet("/health/live",()=>Results.Ok(new{status="live",service="users"})); app.Run();

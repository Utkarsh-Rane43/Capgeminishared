using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Identity;using Microsoft.EntityFrameworkCore;using Pharmacy.Shared;
namespace Users.Api;
[ApiController,Route("api/v1/users")]
public class AuthController(UsersDb db,IConfiguration config):ControllerBase
{
 public record RegisterDto(string Name,string Email,string Password,string? Contact); public record LoginDto(string Email,string Password);
 [HttpPost("register")] public async Task<IActionResult> Register(RegisterDto r){if(string.IsNullOrWhiteSpace(r.Name)||!System.Net.Mail.MailAddress.TryCreate(r.Email,out _)||r.Password.Length<8)return BadRequest(new{message="Enter a valid name/email and password of at least 8 characters."});var email=r.Email.Trim().ToLowerInvariant();if(await db.Users.AnyAsync(x=>x.Email==email))return Conflict(new{message="Email already registered."});var u=new AppUser{Name=r.Name.Trim(),Email=email,Contact=r.Contact,Role="DOCTOR"};u.PasswordHash=new PasswordHasher<AppUser>().HashPassword(u,r.Password);db.Users.Add(u);await db.SaveChangesAsync();return Ok(new{message="Doctor registered. Please log in."});}
 [HttpPost("login")] public async Task<IActionResult> Login(LoginDto r){var u=await db.Users.SingleOrDefaultAsync(x=>x.Email==r.Email.ToLower());if(u==null||!u.IsActive||new PasswordHasher<AppUser>().VerifyHashedPassword(u,u.PasswordHash,r.Password)==PasswordVerificationResult.Failed)return Unauthorized(new{message="Invalid email or password."});return Ok(new{token=JwtSupport.CreateToken(config,u.Id,u.Email,u.Role,u.Name),user=new{id=u.Id,name=u.Name,email=u.Email,role=u.Role}});}
 [HttpGet("me"),Microsoft.AspNetCore.Authorization.Authorize] public IActionResult Me()=>Ok(new{id=User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value,name=User.Identity?.Name,email=User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value,role=User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value});
}

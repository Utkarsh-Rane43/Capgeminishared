using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;
namespace Pharmacy.Shared;
public static class JwtSupport
{
 public static void AddJwt(this IServiceCollection services, IConfiguration config)
 {
  var key=config["Jwt:Key"] ?? "LOCAL_DEMO_ONLY_change_this_key_to_32_chars_minimum";
  services.AddAuthentication("Bearer").AddJwtBearer("Bearer",o=>{o.TokenValidationParameters=new TokenValidationParameters{ValidateIssuer=true,ValidIssuer=config["Jwt:Issuer"]??"PharmacySystem",ValidateAudience=true,ValidAudience=config["Jwt:Audience"]??"PharmacyClients",ValidateIssuerSigningKey=true,IssuerSigningKey=new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)),ValidateLifetime=true,ClockSkew=TimeSpan.FromSeconds(30)};});
  services.AddAuthorization();
 }
 public static string CreateToken(IConfiguration c,long id,string email,string role,string name)
 {
  var key=c["Jwt:Key"] ?? "LOCAL_DEMO_ONLY_change_this_key_to_32_chars_minimum";
  var claims=new[]{new Claim(ClaimTypes.NameIdentifier,id.ToString()),new Claim(ClaimTypes.Email,email),new Claim(ClaimTypes.Role,role),new Claim(ClaimTypes.Name,name)};
  var creds=new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)),SecurityAlgorithms.HmacSha256);
  return new JwtSecurityTokenHandler().WriteToken(new JwtSecurityToken(c["Jwt:Issuer"]??"PharmacySystem",c["Jwt:Audience"]??"PharmacyClients",claims,expires:DateTime.UtcNow.AddHours(8),signingCredentials:creds));
 }
}

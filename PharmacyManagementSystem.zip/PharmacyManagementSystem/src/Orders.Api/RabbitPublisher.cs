using RabbitMQ.Client;using System.Text;using System.Text.Json;
namespace Orders.Api;
public class RabbitPublisher(IConfiguration cfg)
{
 public Task PublishAsync(string eventType,object payload){var factory=new ConnectionFactory{HostName=cfg["RabbitMq:Host"]??"localhost",UserName=cfg["RabbitMq:User"]??"pharmacy",Password=cfg["RabbitMq:Password"]??"pharmacy_demo_password"};try{using var connection=factory.CreateConnection();using var channel=connection.CreateModel();channel.ExchangeDeclare("pharmacy.events",ExchangeType.Topic,durable:true);var envelope=new{eventId=Guid.NewGuid(),eventType,occurredAtUtc=DateTime.UtcNow,version=1,payload};var body=Encoding.UTF8.GetBytes(JsonSerializer.Serialize(envelope));var props=channel.CreateBasicProperties();props.Persistent=true;channel.BasicPublish("pharmacy.events",eventType,props,body);}catch(Exception ex){Console.WriteLine($"RabbitMQ publish skipped: {ex.Message}");}return Task.CompletedTask;}
}

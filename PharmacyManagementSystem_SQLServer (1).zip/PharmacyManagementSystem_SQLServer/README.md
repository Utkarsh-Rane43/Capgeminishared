# Pharmacy Management System – Assessment Project

This is the SQL Server LocalDB version prepared for the training/assessment setup described in our conversations.

## Confirmed environment
- .NET SDKs: 10.0.402 and 10.0.404
- .NET runtimes: 10.0.13 and 10.0.15
- Database tooling: SQL Server Management Studio (SSMS) and LocalDB

The project targets .NET 10 and uses EF Core 10 with the SQL Server provider. It does not use MySQL.

## Architecture
There are five backend Web API microservices and one YARP API Gateway:

| Project | Port | Database |
|---|---:|---|
| AuthService | 5001 | PharmacyAuthDB |
| InventoryService | 5002 | PharmacyInventoryDB |
| OrderService | 5003 | PharmacyOrderDB |
| PaymentService | 5004 | PharmacyPaymentDB |
| SalesReportService | 5005 | PharmacySalesReportDB |
| ApiGateway | 5000 | No database |

Each service owns its own database. Do not query another service's database directly. Services communicate through HTTP APIs and RabbitMQ events.

## Database rule
- C# application data access uses Entity Framework Core and LINQ.
- No handwritten SQL queries are used in C#.
- The only `.sql` script is `database/create-databases.sql`, used to create the five databases in SSMS.
- EF Core `EnsureCreatedAsync()` creates the tables from the C# entity models on first startup.

## Requirements
1. .NET 10 SDK (already present according to the environment information provided).
2. SQL Server LocalDB (the project uses `(localdb)\MSSQLLocalDB` by default).
3. RabbitMQ Server for event messaging. Erlang is required by RabbitMQ.
4. Optional: Node.js and Angular CLI for the frontend stage.

No Docker is required.

## Setup
1. Extract this ZIP.
2. Open `database/create-databases.sql` in SSMS and execute it against `(localdb)\MSSQLLocalDB`.
3. Open `PharmacyManagementSystem.sln` in Visual Studio, or open the folder in VS Code.
4. In PowerShell, run:

```powershell
dotnet restore PharmacyManagementSystem.sln
dotnet build PharmacyManagementSystem.sln
```

5. Start RabbitMQ Server. The default local configuration is `localhost`, user `guest`, password `guest`.
6. Run each backend in its own terminal:

```powershell
dotnet run --project src/AuthService
dotnet run --project src/InventoryService
dotnet run --project src/OrderService
dotnet run --project src/PaymentService
dotnet run --project src/SalesReportService
dotnet run --project src/ApiGateway
```

The services use fixed local ports in their `Properties/launchSettings.json` files. The Gateway listens on port 5000.

## Payment simulator
Set `PaymentSimulation:Outcome` in `src/PaymentService/appsettings.json` to `Success` or `Failure`. This is an internal assessment simulator, not a real payment integration. Never collect card numbers, CVV, UPI PIN, OTP, or banking credentials.

## Deploying without Docker
The services can be published as normal .NET applications:

```powershell
dotnet publish src/AuthService -c Release -o publish/AuthService
```

Repeat for the other projects. On a deployment server, install SQL Server (LocalDB is only suitable for local development/training, not a multi-user production database) and RabbitMQ, change connection strings and secrets, and host the APIs behind IIS or another reverse proxy with HTTPS.

## Important project status
This ZIP gives you a coherent beginner-oriented starting project with the service structure, EF Core entities, LINQ data access, API endpoints, YARP routes, RabbitMQ event contracts/publishing/consuming, and setup/deployment notes.

It is not honestly possible to guarantee zero build errors without running restore/build on your actual company laptop. Also, the starter still needs end-to-end integration work, security hardening, stock reservation compensation, retry/outbox handling, Angular screens and automated tests before it should be described as production-ready. The first task after extraction is to build it and fix any machine-specific errors.

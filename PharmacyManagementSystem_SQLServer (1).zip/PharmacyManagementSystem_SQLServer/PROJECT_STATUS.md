# Project status

This ZIP is the SQL Server LocalDB edition of the Pharmacy Management System. It targets .NET 10, matching the SDK/runtime versions shared by the user. It uses EF Core SQL Server and LINQ in application code, SQL only to create databases, ASP.NET Core Web APIs (minimal APIs, not MVC), YARP, RabbitMQ, and no Docker.

It contains the five backend services, separate database contexts/entities, a gateway, RabbitMQ event contracts/publisher/consumer, a basic PDF invoice endpoint, sales report endpoints, a solution file, SQL database creation script, API notes, and deployment instructions.

A build has not been run on the user's laptop. Package restore and compilation must be checked there. This is an assessment starter, not a claim of zero errors or production certification. The limitations in `docs/ASSESSMENT_NOTES.md` should be completed before final submission.

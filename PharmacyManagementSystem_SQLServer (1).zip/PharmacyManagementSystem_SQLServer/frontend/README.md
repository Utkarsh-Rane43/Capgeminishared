# Angular Frontend

The backend APIs are prepared first so they can be tested independently. Create the Angular application on the development machine when Node.js is available:

```powershell
npm install -g @angular/cli
ng new pharmacy-frontend --routing --style=css
cd pharmacy-frontend
ng generate component login
ng generate component dashboard
ng generate component medicines
ng generate component suppliers
ng generate component orders
ng generate component reports
```

Set the frontend API base URL to `http://localhost:5000`. Use the API Gateway for backend calls, not the individual service ports.

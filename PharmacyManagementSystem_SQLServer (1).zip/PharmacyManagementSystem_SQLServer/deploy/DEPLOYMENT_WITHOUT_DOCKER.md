# Deployment without Docker

1. Install the .NET 10 Hosting Bundle on the Windows server.
2. Install SQL Server Express or a supported full SQL Server instance. LocalDB is for local development and is not suitable for a multi-user production server.
3. Install RabbitMQ Server and Erlang.
4. Create the five databases and configure each service's connection string.
5. Replace the development JWT key and default RabbitMQ credentials with secure secrets.
6. Publish each service:

```powershell
dotnet publish src/AuthService -c Release -o C:\PharmacyApps\AuthService
dotnet publish src/InventoryService -c Release -o C:\PharmacyApps\InventoryService
dotnet publish src/OrderService -c Release -o C:\PharmacyApps\OrderService
dotnet publish src/PaymentService -c Release -o C:\PharmacyApps\PaymentService
dotnet publish src/SalesReportService -c Release -o C:\PharmacyApps\SalesReportService
dotnet publish src/ApiGateway -c Release -o C:\PharmacyApps\ApiGateway
```

7. Run each published service under a managed Windows Service or host it behind IIS with the ASP.NET Core Hosting Bundle.
8. Expose only the gateway publicly. Restrict service and database ports using firewall rules.
9. Configure HTTPS, backups, least-privilege SQL logins, RabbitMQ credentials, logging and monitoring.

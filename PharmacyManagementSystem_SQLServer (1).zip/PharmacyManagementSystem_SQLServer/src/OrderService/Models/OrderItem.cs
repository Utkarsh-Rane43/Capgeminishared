namespace OrderService.Models;

public class OrderItem
{
    public int Id { get; set; }
    public int CustomerOrderId { get; set; }
    public int DrugId { get; set; }
    public string DrugName { get; set; } = "";
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal GstRate { get; set; }
    public decimal GstAmount { get; set; }
    public decimal LineTotal { get; set; }
}

using System.Text;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using SalesReportService.Data;
using SalesReportService.Models;
using Shared.Contracts;

namespace SalesReportService.Workers;

public class PaymentEventWorker : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly IConfiguration _configuration;
    private IConnection? _connection;
    private IModel? _channel;

    public PaymentEventWorker(IServiceScopeFactory scopeFactory, IConfiguration configuration)
    {
        _scopeFactory = scopeFactory;
        _configuration = configuration;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                StartRabbitConsumer();
                return;
            }
            catch (Exception)
            {
                await Task.Delay(TimeSpan.FromSeconds(10), stoppingToken);
            }
        }
    }

    private void StartRabbitConsumer()
    {
        var factory = new ConnectionFactory
        {
            HostName = _configuration["RabbitMQ:Host"] ?? "localhost",
            UserName = _configuration["RabbitMQ:User"] ?? "guest",
            Password = _configuration["RabbitMQ:Password"] ?? "guest",
            DispatchConsumersAsync = true
        };

        _connection = factory.CreateConnection();
        _channel = _connection.CreateModel();

        _channel.ExchangeDeclare("pharmacy.events", ExchangeType.Topic, durable: true);
        _channel.QueueDeclare("sales-report-payment-success", durable: true, exclusive: false, autoDelete: false);
        _channel.QueueBind("sales-report-payment-success", "pharmacy.events", "payment.succeeded");

        var consumer = new AsyncEventingBasicConsumer(_channel);

        consumer.Received += async (sender, eventArgs) =>
        {
            var json = Encoding.UTF8.GetString(eventArgs.Body.ToArray());
            var paymentEvent = JsonSerializer.Deserialize<PaymentSucceededEvent>(json);

            if (paymentEvent != null)
            {
                using var scope = _scopeFactory.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<ReportDbContext>();

                var existingSale = await db.Sales.FirstOrDefaultAsync(
                    sale => sale.OrderId == paymentEvent.OrderId);

                if (existingSale == null)
                {
                    var sale = new SaleRecord
                    {
                        OrderId = paymentEvent.OrderId,
                        Amount = paymentEvent.Amount,
                        PaidAt = paymentEvent.PaidAt
                    };

                    db.Sales.Add(sale);
                    await db.SaveChangesAsync();
                }
            }

            _channel!.BasicAck(eventArgs.DeliveryTag, multiple: false);
        };

        _channel.BasicConsume("sales-report-payment-success", autoAck: false, consumer);
    }

    public override void Dispose()
    {
        _channel?.Close();
        _connection?.Close();
        base.Dispose();
    }
}

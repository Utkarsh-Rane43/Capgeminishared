namespace InventoryService.Models;

public class Drug
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public decimal Price { get; set; }
    public decimal GstRate { get; set; }
    public int StockQuantity { get; set; }
    public bool IsActive { get; set; } = true;
}

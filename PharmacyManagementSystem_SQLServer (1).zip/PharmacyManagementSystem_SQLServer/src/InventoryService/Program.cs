using InventoryService.Data;
using InventoryService.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<InventoryDbContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"));
});

builder.Services.AddOpenApi();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<InventoryDbContext>();
    await db.Database.EnsureCreatedAsync();
}

app.MapGet("/", () => "InventoryService is running.");

app.MapGet("/api/drugs", async (InventoryDbContext db) =>
{
    var drugs = await db.Drugs
        .Where(drug => drug.IsActive)
        .OrderBy(drug => drug.Name)
        .ToListAsync();

    return Results.Ok(drugs);
});

app.MapGet("/api/drugs/{id:int}", async (int id, InventoryDbContext db) =>
{
    var drug = await db.Drugs.FirstOrDefaultAsync(item => item.Id == id);

    if (drug == null)
    {
        return Results.NotFound();
    }

    return Results.Ok(drug);
});

app.MapPost("/api/drugs", async (Drug drug, InventoryDbContext db) =>
{
    if (string.IsNullOrWhiteSpace(drug.Name) ||
        drug.Price < 0 || drug.GstRate < 0 || drug.StockQuantity < 0)
    {
        return Results.BadRequest("Please enter valid drug details.");
    }

    db.Drugs.Add(drug);
    await db.SaveChangesAsync();

    return Results.Created($"/api/drugs/{drug.Id}", drug);
});

app.MapPut("/api/drugs/{id:int}", async (int id, Drug request, InventoryDbContext db) =>
{
    var drug = await db.Drugs.FirstOrDefaultAsync(item => item.Id == id);

    if (drug == null)
    {
        return Results.NotFound();
    }

    drug.Name = request.Name;
    drug.Description = request.Description;
    drug.Price = request.Price;
    drug.GstRate = request.GstRate;
    drug.StockQuantity = request.StockQuantity;
    drug.IsActive = request.IsActive;

    await db.SaveChangesAsync();

    return Results.Ok(drug);
});

app.MapGet("/api/suppliers", async (InventoryDbContext db) =>
{
    var suppliers = await db.Suppliers
        .OrderBy(supplier => supplier.Name)
        .ToListAsync();

    return Results.Ok(suppliers);
});

app.MapPost("/api/suppliers", async (Supplier supplier, InventoryDbContext db) =>
{
    db.Suppliers.Add(supplier);
    await db.SaveChangesAsync();

    return Results.Created($"/api/suppliers/{supplier.Id}", supplier);
});

app.MapPost("/api/inventory/reduce/{id:int}", async (int id, StockRequest request, InventoryDbContext db) =>
{
    var drug = await db.Drugs.FirstOrDefaultAsync(item => item.Id == id);

    if (drug == null)
    {
        return Results.NotFound("Drug not found.");
    }

    if (request.Quantity <= 0 || drug.StockQuantity < request.Quantity)
    {
        return Results.BadRequest("Invalid quantity or insufficient stock.");
    }

    drug.StockQuantity -= request.Quantity;
    await db.SaveChangesAsync();

    return Results.Ok(new { message = "Stock updated.", drug.StockQuantity });
});

app.Run();

public record StockRequest(int Quantity);

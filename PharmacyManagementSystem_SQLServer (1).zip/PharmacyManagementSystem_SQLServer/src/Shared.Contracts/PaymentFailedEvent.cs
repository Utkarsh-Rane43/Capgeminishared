namespace Shared.Contracts;

public class PaymentFailedEvent
{
    public int OrderId { get; set; }
    public string Reason { get; set; } = "";
    public DateTime FailedAt { get; set; }
}

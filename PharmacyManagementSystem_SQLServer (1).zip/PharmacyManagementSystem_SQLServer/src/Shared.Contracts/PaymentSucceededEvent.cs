namespace Shared.Contracts;

public class PaymentSucceededEvent
{
    public int OrderId { get; set; }
    public decimal Amount { get; set; }
    public DateTime PaidAt { get; set; }
}

# API endpoints

During local development, each service exposes an OpenAPI document at `/openapi/v1.json`.

| Method | URL | Purpose |
|---|---|---|
| POST | `/api/auth/register` | Register a doctor |
| POST | `/api/auth/login` | Login and receive JWT |
| GET | `/api/auth/users` | List users (requires JWT) |
| GET | `/api/drugs` | List active drugs |
| GET | `/api/drugs/{id}` | Get one drug |
| POST | `/api/drugs` | Add a drug |
| PUT | `/api/drugs/{id}` | Update a drug |
| GET | `/api/suppliers` | List suppliers |
| POST | `/api/suppliers` | Add supplier |
| POST | `/api/orders` | Create order |
| GET | `/api/orders` | List orders |
| GET | `/api/orders/{id}` | Get order |
| POST | `/api/payments/simulate` | Simulate payment |
| GET | `/api/payments` | List payments |
| GET | `/api/invoices/{id}/pdf` | Download invoice PDF |
| GET | `/api/reports/daily` | Daily report |
| GET | `/api/reports/weekly` | Weekly report |
| GET | `/api/reports/monthly` | Monthly report |

The YARP gateway forwards the same API paths through port 5000.
